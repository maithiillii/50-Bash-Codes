#!/bin/bash
read -p "Enter limit: " n
for ((i=1; i<=n; i++)); do echo -n "$i "; done
echo
