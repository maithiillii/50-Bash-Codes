#!/bin/bash
read -p "Enter number: " n
echo "$((n * n * n))"
