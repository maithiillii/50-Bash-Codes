#!/bin/bash
read -p "Enter a character: " c
printf "%d\n" "'$c"
